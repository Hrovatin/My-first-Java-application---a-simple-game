package objectStorage;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Abstract storage class for storing different types of objects
 * which can be retrieved by their names.
 * Stores name-object pairs.
 * @param <T> type of the objects to be stored
 */
public abstract class ObjectStorage<T> {
	
	private HashMap<String, T> storage=new HashMap<String,T>();

	/**
	 * Add a new object-name pair in the collection.
	 * @param name of the object
	 * @param obj instance of the object
	 */
	public void add(String name, T obj) {
		storage.put(name,obj);
	}
	
	/**
	 * Get object by its name.
	 * @param name of the required object
	 * @return instance of the required object
	 */
	public T get(String name) {
		T obj=storage.get(name);
		return obj;
	}
	
	/**
	 * Check if the collection contains object with that name.
	 * @param name of the object of interest
	 * @return true if the collection contains corresponding object, else false
	 */
	public Boolean has(String name) {
		return storage.containsKey(name);
	}
	
	/**
	 * Return all objects stored in the collection.
	 * @return all stored instances
	 */
	public HashSet<T> getAll() {
		HashSet<T> allObjects=new HashSet<T>();
		for (T object: storage.values()) {
			allObjects.add(object);
		}
		return allObjects;
	}
	
	/**
	 * Return names of all the objects stored in the collection.
	 * @return all objects' names
	 */
	public Set<String> getAllNames() {
		Set<String> allObjectNames=storage.keySet();
		return allObjectNames;
	}
	
}
