package objectStorage;

import item.Item;

/**
 * This class (singleton) stores all the items present in the game.
 * @param <T> Item
 */
public class ItemStorage<T> extends ObjectStorage<T>{
	
	private static ItemStorage<Item> instance = null; 
	
	/**
	 * Singleton constructor.
	 */
	private ItemStorage() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static ItemStorage<Item> getInstance() {
       
		if (instance == null) 
            instance = new ItemStorage<Item>(); 
  
        return instance; 
    } 

}

