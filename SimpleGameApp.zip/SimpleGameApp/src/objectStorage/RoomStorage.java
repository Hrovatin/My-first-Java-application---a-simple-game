package objectStorage;

//import java.util.HashMap;

import itemStoring.Room;

/**
 * This class (singleton) stores all the rooms present in the game.
 * @param <T> Room
 */
public class RoomStorage<T> extends ObjectStorage<T>{
	
	private static RoomStorage<Room> instance = null; 
	
	/**
	 * Singleton constructor.
	 */
	private RoomStorage() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static RoomStorage<Room> getInstance() {
       
		if (instance == null) 
            instance = new RoomStorage<Room>(); 
  
        return instance; 
    } 
	
}
