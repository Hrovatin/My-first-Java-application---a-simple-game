package objectStorage;

import controller.Controller;

/**
 * This class (singleton) stores all the controllers present in the game.
 * @param <T> Controller
 */
// As this game currently supports only single-player game 
// this storage contains the single controller.
public class ControllerStorage<T> extends ObjectStorage<T>{
	
	private static ControllerStorage<Controller> instance = null; 
	
	/**
	 * Singleton constructor.
	 */
	private ControllerStorage() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static ControllerStorage<Controller> getInstance() {
       
		if (instance == null) 
            instance = new ControllerStorage<Controller>(); 
  
        return instance; 
    } 

}
