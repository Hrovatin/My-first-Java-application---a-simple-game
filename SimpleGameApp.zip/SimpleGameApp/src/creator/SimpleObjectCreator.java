package creator;

import creator.ObjectCreatorHelper;

/**
 * Class (singleton) for hard-coding information about game (player, rooms, items, images, movements). 
 * It calls methods from the ObjectCreatorHelper and passes hard-coded parameters.
 */
public class SimpleObjectCreator implements Creator{
	
	private static SimpleObjectCreator instance = null; 
	private ObjectCreatorHelper helper=ObjectCreatorHelper.getInstance();
	
	/**
	 * Singleton constructor
	 */
	private SimpleObjectCreator() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static SimpleObjectCreator getInstance() {
       
		if (instance == null) 
            instance = new SimpleObjectCreator(); 
  
        return instance; 
    } 
	
	/**
	 * Calls helper methods to create all in-game objects and information.
	 * The order of methods is important as further checks are performed 
	 * on the imported information in the helper class.
	 * Player, room exits and room images need to be created after rooms and directions 
	 * (some also hard-encoded in Directions class) to check if their position is valid.
	 * Items must be added to itemStorages after they are created in order to add only valid items.
	 */
	public void start() {		
		helper.createRoom("Ambulanta1");
		helper.createRoom("WaitingRoom");
		helper.addExit("Ambulanta1","east", "middle", "WaitingRoom");
		helper.addExit("WaitingRoom","west", "middle", "Ambulanta1");
		helper.createPlayer("WaitingRoom","north");
		helper.createItem("pinkToothfairy", "pinkToothfairy.png");
		helper.createItem("teeth", "teeth.png");
		helper.addPlayerItem("pinkToothfairy", 1);
		helper.addRoomItem("WaitingRoom", "teeth", 1);
		helper.saveRoomImage("WaitingRoom", "north", "WR_N.png");
		helper.saveRoomImage("WaitingRoom", "south", "WR_S.png");
		helper.saveRoomImage("WaitingRoom", "east", "WR_E.png");
		helper.saveRoomImage("WaitingRoom", "west", "WR_W.png");
		helper.saveRoomImage("Ambulanta1", "north", "A1_N.png");
		helper.saveRoomImage("Ambulanta1", "south", "A1_S.png");
		helper.saveRoomImage("Ambulanta1", "east", "A1_E.png");
		helper.saveRoomImage("Ambulanta1", "west", "A1_W.png");
	}
	
}
