package creator;

import commands.*;
import controller.Controller;
import itemStoring.*;
import objectStorage.*;
import view.ControllerGUI;
import view.Pictures;
import item.Item;

/**
 * This class (singleton) creates game objects, passes them into storages 
 * and adds information to previously created objects.
 * Information for these actions is passed by calling its method from creator classes.
 */
public class ObjectCreatorHelper {
	
	private static ObjectCreatorHelper instance = null; 
	private RoomStorage<Room> rooms=RoomStorage.getInstance();
	private ItemStorage<Item> items=ItemStorage.getInstance();
	private Pictures pictureStorage=Pictures.getInstance();
	private Directions directionStorage=Directions.getInstance();
	private ControllerGUI gui;
	private Player player;
	
	/**
	 * Singleton constructor
	 */
	private ObjectCreatorHelper() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static ObjectCreatorHelper getInstance() {
       
		if (instance == null) 
            instance = new ObjectCreatorHelper(); 
  
        return instance; 
    } 
	
	/**
	 * Method for passing GUI controller from JavaFX Application Start method into this class
	 * and subsequently to the main game controller.
	 * Field this.gui is overwritten with each created GUI.
	 * @param gui controller for GUI
	 */
	public void setGUIController(ControllerGUI gui) {
		this.gui=gui;
	}

	/**
	 * Create new room and add it to the room storage.
	 * @param name of the room as will be displayed to the user
	 */
	protected void createRoom(String name) {
		Room room = new Room(name);
		rooms.add(name, room);
	}
	
	/**
	 * Create player with start position and associated non-GUI controller and 
	 * possible commands class for the player.
	 * Non-GUI controller and possible commands are passed to the GUI controller.
	 * Controller is stored in controllerStorage.
	 * @param roomName player's starting room
	 * @param directionName player's starting direction
	 */
	protected void createPlayer(String roomName, String directionName) {
		
//		Create a new player. Checks if start position is valid, else automatically chooses a valid position.
//		If the position was chosen automatically it prints a message to the command line.
		if (!rooms.has(roomName)) {
			System.out.println("Player's starting possition will be set automatically as room \""
					+roomName+"\" could not be found amongst rooms.");
			roomName=rooms.getAllNames().toArray()[0].toString();
		}
		if (!directionStorage.hasDirection(directionName)) {
			System.out.println("Player's starting possition will be set automatically as direction \""
					+directionName+"\" is not a valid direction.");
			directionName=directionStorage.getAllDirections().toArray()[0].toString();
		}
		player=new Player(roomName, directionName);

//		Create classes associated with each player. If multy-player option was supported this 
//		is where StartWithFX main method would be called (requires multy-threading).
		UserPossibleCommands comands=new UserPossibleCommands(player);
		Controller controller=new Controller(gui,player);
		ControllerStorage<Controller> controllers=ControllerStorage.getInstance();
//		As this design supports only 1 player the addition of two controller is not supported as 
//		well (the first one will be overwritten).
		controllers.add("1",controller);
		gui.fieldsView(controller, comands);
	}
	
	/**
	 * Create new item and add it itemStorage. 
	 * Picture file name is stored in the Pictures class.
	 * @param name of the item
	 * @param imagePath for item's image
	 */
	protected void createItem(String name, String imagePath) {
		Item item=new Item(name);
		items.add(name, item);
		pictureStorage.addItemPicture(name, imagePath);
	}
	
	/**
	 * Save image file name for a view direction of room in the Pictures class. 
	 * Checks that room and direction of the picture are valid.
	 * Else prints an error message to the command line.
	 * @param roomName name of the room
	 * @param direction direction in room for the picture
	 * @param imagePath name of file with the image
	 */
	protected void saveRoomImage(String roomName, String direction, String imagePath) {
		if(rooms.has(roomName)&&directionStorage.hasDirection(direction)) {
			pictureStorage.addRoomPicture(roomName, direction, imagePath);
		}
		else {
			System.out.println("Image could not be added to room images as "+roomName+" or "+direction+" does not exits.");
		}
	}
	
	/**
	 * Creation of new movement possibilities.
	 * @param turnMovement name of the movement
	 * @param startDirection start direction of the movement
	 * @param endDirection end direction of the movement
	 */
	protected void turnDirections(String turnMovement, String startDirection, String endDirection) {
//	Prior presence of turn movements and directions is not checked as they can be created de novo here.
		directionStorage.addTurnDirection(turnMovement, startDirection, endDirection);
	}
	
	/**
	 * Add exit to a room object. 
	 * Checks that starting and ending rooms and the direction of exit in the starting room are valid.
	 * Else prints an error message to the command line.
	 * @param roomName name of the room
	 * @param direction direction of the exit in the room
	 * @param doorPosition position of exit in that direction; displayed to the user, 
	 * 		  if there is only one exit in that direction it can be set to a standard eg. "exit"
	 * @param neighbour room that will be accessed through this exit
	 */
	protected void addExit(String roomName,String direction, String doorPosition, String neighbour) {
		if(rooms.has(roomName)&&rooms.has(neighbour)&&directionStorage.hasDirection(direction)) {
			rooms.get(roomName).addExit(direction, doorPosition, neighbour);
		}
		else {
			System.out.println(doorPosition+" "+direction+" exit in "+roomName+" to "+neighbour+" could not be added");
		}
	}
	
	/**
	 * Add a number of items to the player if item object with that name exists.
	 * Else prints an error message to the command line.
	 * @param itemName name of the item object
	 * @param number number of items to be added
	 */
//	If multy-player option was supported this method should also have parameter with 
//	player's id (currently neither is included in the game).
	protected void addPlayerItem(String itemName, Integer number) {
		if (items.has(itemName)) {
			player.add(itemName,number);
		}
		else{
			System.out.println("Item "+itemName+" does not exist and thus could not be added to the player.");
		}
	}
	
	/**
	 * Add a number of items to a room if item object and room with that name exist.
	 * Else prints an error message to the command line.
	 * @param room where the item will be placed
	 * @param itemName name of the item object
	 * @param number number of items to be added
	 */
	protected void addRoomItem(String room, String itemName, Integer number) {
		if (items.has(itemName)&&rooms.has(room)) {
			rooms.get(room).add(itemName,number);
		}
		else{
			System.out.println("Item "+itemName+"  could not be added to the room "+room+ " as one of the does not exist.");
		}
	}
	
}
