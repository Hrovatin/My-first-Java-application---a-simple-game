package creator;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

import org.json.*;
import commands.Directions;

/**
 * Class (singleton) for processing information from JSON file. 
 * It supports addition of rooms with exits, items, player with start position, 
 * images for rooms and items, possible movements and initial item locations.
 * The JSON file needs to have specified: rooms with views, exits and contents and 
 * items with names and images.
 * It may also include: player with start room and direction and with contents, 
 * movements.
 */
public class ReaderJSON implements Creator{
	
	private static ReaderJSON instance = null; 
	private Directions directionStorage=Directions.getInstance();
	private ObjectCreatorHelper helper=ObjectCreatorHelper.getInstance();
	private String fileStr;
	private JSONObject obj;
	private HashSet<String> roomSet=new HashSet<String>();
	private HashSet<String> directionSet=new HashSet<String>();
	
	
	/**
	 * Singleton constructor
	 */
	private ReaderJSON() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static ReaderJSON getInstance() {
	       
		if (instance == null) 
            instance = new ReaderJSON(); 
  
        return instance; 
    } 
	
	/**
	 * Calls all methods needed to process the JSON file.
	 * The order of methods is important as further checks are performed 
	 * on the imported information in the helper class.
	 * Player, room exits and room images need to be created after rooms and directions 
	 * (some also hard-encoded in Directions class)  to check if their position is valid.
	 * Items must be added to itemStorages after they are created in order to add only valid items.
	 */
	public void start() {
		file();
		createRooms();
		turnMovements();
		directionSet=directionStorage.getAllDirections();
		createPlayer();
		roomPictures();
		roomExits();
		createItem();
		roomItems();
		playerItems();
	}
	
	/**
	 * Turns JSON file into JSON object.
	 */
	private void file() {
		
//		Read the file and produce a string of its contents. 
//		The JSON file must be in the same package as this class.
//		File name must be specified in the next line of code.
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(getClass().getResourceAsStream("json.json"));
		while(scanner.hasNextLine()){
			if (fileStr==null) {
				fileStr = scanner.nextLine();
			}
			else {
				fileStr = fileStr+scanner.nextLine();
			}
		}
		
//		Create new JSON object from the file string.
		obj = new JSONObject(fileStr);
	}
	
	/**
	 * Processes information for creation of a new room.
	 */
	private void createRooms() {
		Iterator<String> rooms = obj.getJSONObject("rooms").keys();
		while (rooms.hasNext()){
			String room=rooms.next();
			roomSet.add(room);
			helper.createRoom(room);
		}
	}
	
	/**
	 * Processes information for addition of movement options (movements, directions). 
	 * It also excepts a JSON file without specified movements 
	 * (how movements are determined in such a case is specified in Directions class).
	 */
	private void turnMovements() {
		if(obj.has("movements")) {
			Iterator<String> movements=obj.getJSONObject("movements").keys();
			while (movements.hasNext()) {
				String movement=movements.next();
				Iterator<String> starts=obj.getJSONObject("movements").getJSONObject(movement).keys();
				while (starts.hasNext()) {
					String start=starts.next();
					String stop=obj.getJSONObject("movements").getJSONObject(movement).getString(start);
					helper.turnDirections(movement, start, stop);
				}
			}
		}
	}
	
	/**
	 * Processes information for addition of room pictures.
	 */
	private void roomPictures() {
		for (String room:roomSet) {
			for (String direction:directionSet) {
				String image= obj.getJSONObject("rooms").getJSONObject(room).getJSONObject("views").getString(direction);
				helper.saveRoomImage(room, direction, image);
			}
		}
	}
	
	/**
	 * Processes information for addition of room exits and their connections.
	 * It allows JSON file to have either only one or multiple exits in each room's direction.
	 */
	private void roomExits() {
		
		for (String room:roomSet) {
			for (String direction:directionSet) {
				JSONObject exitObj= obj.getJSONObject("rooms").getJSONObject(room).getJSONObject("exits");
				if(exitObj.has(direction)) {
					
					if (exitObj.get(direction) instanceof JSONObject) {
						Iterator<String> exitPositions = exitObj.getJSONObject(direction).keys();
						while (exitPositions.hasNext()) {
							String doorPosition=exitPositions.next();
							String neighbour=exitObj.getJSONObject(direction).getString(doorPosition);
							helper.addExit(room, direction, doorPosition, neighbour);						
						}
					}
					else {
						String doorPosition="exit";
						String neighbour=exitObj.getString(direction);
						helper.addExit(room, direction, doorPosition, neighbour);
					}
				}
			}
		}
	}
	
	/**
	 * Processes information for addition of items to rooms.
	 */
	private void roomItems(){
		for (String room:roomSet) {
			JSONObject roomObj=obj.getJSONObject("rooms").getJSONObject(room);
			if (roomObj.has("contents")){
				JSONArray items=roomObj.getJSONArray("contents");
				for(int i = 0; i < items.length(); i++) {
//					
					if (items.get(i) instanceof JSONObject) {
						JSONObject itemObject=items.getJSONObject(i);
						Iterator<String> itemNames=itemObject.keys();
						while (itemNames.hasNext()) {
							String itemName=itemNames.next();
							Integer number=itemObject.getInt(itemName);
							helper.addRoomItem(room, itemName,number);
						}
					}
//					If item is not given as JSONObject with count it sets its number to 1.
					else {
						helper.addRoomItem(room, items.getString(i),1);
					}
				}
			}
		}
	}
	
	/**
	 * Processes information for addition of items to player.
	 * It allows for no player to be specified in JSON file.
	 */
	private void playerItems() {
		if (obj.has("player")) {
			JSONObject playerObj=obj.getJSONObject("player");
			if (playerObj.has("contents")) {
				JSONArray items =playerObj.getJSONArray("contents");
				for(int i = 0; i < items.length(); i++) {
					if (items.get(i) instanceof JSONObject) {
						JSONObject itemObject=items.getJSONObject(i);
						Iterator<String> itemNames=itemObject.keys();
						while (itemNames.hasNext()) {
							String itemName=itemNames.next();
							Integer number=itemObject.getInt(itemName);
							helper.addPlayerItem(itemName,number);
						}
					}
//					If item is not given as JSONObject with count it sets its number to 1.
					else {
						helper.addPlayerItem(items.getString(i),1);
					}
				}
			}
		}
	}
	
	/**
	 * Processes information for item creation.
	 */
	private void createItem() {
		Iterator<String> items =obj.getJSONObject("items").keys();
		while(items.hasNext()) {
			String item=items.next();
			String imagePath=obj.getJSONObject("items").getJSONObject(item).getString("image");
			helper.createItem(item, imagePath);
		}
	}
	
	/**
	 * Processes information for player creation.
	 * It allows for no player to be specified in JSON file.
	 */
	private void createPlayer() {
		String startRoom=null;
		String startDirection=null;
		
		if (obj.has("player")) {
			
			if(obj.getJSONObject("player").has("start room")){
				startRoom=obj.getJSONObject("player").getString("start room");
			}
			else {
				startRoom="";			
			}
			
			if(obj.getJSONObject("player").has("start direction")){
				startDirection=obj.getJSONObject("player").getString("start direction");
			}
			else {
				startDirection="";			
			}
		}
		
		else {
			startRoom="";
			startDirection="";
		}
		
		helper.createPlayer(startRoom, startDirection);
	}
	
}
























































