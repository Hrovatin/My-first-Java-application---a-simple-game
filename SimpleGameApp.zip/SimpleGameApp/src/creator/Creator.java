package creator;

/**
 * Interface for creator classes. 
 */
public interface Creator {
	
	/**
	 * Calls any other creator methods in order to create the game world.
	 * Only public method (except for Singleton getInstance method) of creator classes.
	 */
	public void start();
	
}
