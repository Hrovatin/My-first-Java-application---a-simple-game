package itemStoring;

import org.apache.commons.collections4.bag.HashBag;

/**
 * Abstract class that provides item storing functionality.
 */
public abstract class ItemStoring {
	
	private HashBag<String> items=new HashBag<String>();
	
	/**
	 * Ad item in collection by its name.
	 * @param itemName name of the item to be added
	 * @param number number of items to be added
	 */
	public void add(String itemName, Integer number) {
		items.add(itemName,number);
	}
	
	/**
	 * Remove number of items with that name from the collection.
	 * @param itemName name of the item to be removed
	 * @param number number of items to be removed
	 */
	public void remove(String itemName, Integer number) {
		items.remove(itemName,number);
	}
	
	/**
	 * Returns all item names and count of items stored in the object of the 
	 * class extending this class.
	 * @return names of all stored items
	 */
	public HashBag<String> getItems(){
		return items;
	}

}
