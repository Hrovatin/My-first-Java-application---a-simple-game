package itemStoring;

import java.util.Set;
import itemStoring.ItemStoring;
import org.apache.commons.collections4.map.MultiKeyMap;
import org.apache.commons.collections4.multimap.HashSetValuedHashMap;

/**
 * Stores information about a room. This includes information set
 * before user's input (exits, name) and information about current state (items).
 *
 */
public class Room extends ItemStoring{
	
	private String name;
	private MultiKeyMap<String,String> exits;
	private HashSetValuedHashMap<String,String> doors;
	
	/**
	 * Set the name of the room. 
	 * This name will be used in code and will be displayed to the user.
	 * @param name room's name
	 */
	public Room(String name) {
		this.name=name;
		exits=new MultiKeyMap<String,String>();
		doors=new HashSetValuedHashMap<String,String>();
	}
	
	/**
	 * Return name of the room.
	 * @return room's name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Stores room's exit in particular direction and the room on
	 * the other side of the exit.
	 * @param direction view direction in which exit is located
	 * @param doorPosition position/name of the exit in particular direction
	 * @param neighbour name of the room accessed through this exit
	 */
	public void addExit(String direction, String doorPosition, String neighbour) {
		exits.put(direction, doorPosition, neighbour);
		doors.put(direction,doorPosition);
	}

	/**
	 * Return all exits of the room in that direction.
	 * @param direction of the exit inquiry
	 * @return set of exits in that direction
	 */
	public Set<String> getExits(String direction) {
		return doors.get(direction);
	}
	
	/**
	 * Get the name of the rum that is accessible through a particular exit.
	 * @param direction of the exit
	 * @param doorPosition position/name of the exit in that direction
	 * @return
	 */
	public String getNextRoom(String direction,String doorPosition) {
		return exits.get(direction,doorPosition);
	}
	
	/**
	 * Check if room has no exits.
	 * @return true if room has no exits, else false
	 */
	public Boolean hasNoExit() {
		return exits.isEmpty();
	}
	
}
