package itemStoring;
import itemStoring.ItemStoring;

/**
 * Stores information about the player. 
 * This includes information set before the beginning of the game (name) and 
 * current information (location, stored items). *
 */
public class Player extends ItemStoring {
	
	private String roomName;
	private String direction;

	/**
	 * Creates player with specified location.
	 * @param roomName name of the player's starting room.
	 * @param direction in which the player starts the game
	 */
	public Player(String roomName, String direction) {
		this.roomName=roomName;
		this.direction=direction;
	}
	
	/**
	 * Change the room in which the player is located.
	 * @param roomName name of the new room location
	 */
	public void setRoom(String roomName) {
		this.roomName=roomName;
	}
	
	/**
	 * Change players direction.
	 * @param direction new direction the player is facing
	 */
	public void setDirection(String direction) {
		this.direction=direction;
	}
	
	/**
	 * Return name of the room in which player is located.
	 * @return name of the current room
	 */
	public String getCurrentRoom() {
		return roomName;
	}
	
	/**
	 * Return direction which the player is facing.
	 * @return current direction
	 */
	public String getCurrentDirection() {
		return direction;
	}
	
}
