package controller;

import commands.Directions;
import itemStoring.*;
import objectStorage.*;
//All views are imported (eg. whole package) in order to allow changing of views in the future.
import view.*;

/**
 * Navigates actions performed by the user (player) to the concerned objects.
 * Changes location of player and items inside the player and itemStoring objects.
 * Each controller (if multy-player option was enabled) deals with one player
 * and is connected to one GUI. It accesses a common set of rooms and items within them. 
 */
public class Controller {
	
	private ControllerGUI gui;
	private Player player;
	private RoomStorage<Room> rooms=RoomStorage.getInstance();
	private Directions directions=Directions.getInstance();

	/**
	 * Store the relevant player and GUI.
	 * @param gui associated with this controller
	 * @param player associated with this controller
	 */
	public Controller(ControllerGUI gui, Player player) {
		this.gui=gui;
		this.player=player;
	}
	
	/**
	 * This is next step after object creation. It starts the GUI method
	 * for showing the first player's view.  
	 */
//	This could be improved with also showing the stage here to avoid showing a 
//	non complete stage before all the object creation is executed 
//	(or previously only showing a temporary scene). However, as all the steps
//	are currently executed quickly (no incomplete GUI is be viewed) 
//	I did not complicate my design with this.
	public void start() {	
		gui.start();
	}
	
	/**
	 * Returns current room object based on name of the room in 
	 * which the player is located.
	 * @return current room object
	 */
	private Room currentRoom() {
		String curentRoomName=player.getCurrentRoom();
		Room currentRoom=rooms.get(curentRoomName);
		return currentRoom;
	}
	
	/**
	 * Processes player's action of putting down an item from current room.
	 * Item is removed from player and added to the current room.
	 * Calls GUI to change the user's view.
	 * @param itemName name of the item that was put down
	 * @param number number of items that were put down
	 */
	public void putDownResponse(String itemName, Integer number) {
		player.remove(itemName,number);
		Room room = this.currentRoom();
		room.add(itemName,number);
		gui.itemChange();
	}

	/**
	 * Processes player's action of picking up an item from current room.
	 * Item is removed from the current room and added to the player.
	 * Calls GUI to change the user's view.
	 * @param itemName name of the item that was picked up
	 * @param number number of items that were picked up
	 */
	public void pickUpResponse(String itemName, Integer number) {
		Room room = this.currentRoom();
		room.remove(itemName,number);
		player.add(itemName,number);
		gui.itemChange();
	}
	
	/**
	 * Responds to exiting a room based on current room and direction.
	 * Changes player's room and calls GUI to change the user's view.
	 * It is assumed that direction is not changed when exiting a room.
	 * @param doorPosition name of the chosen door
	 */
	public void goResponse(String doorPosition) {
		String direction=player.getCurrentDirection();
		Room room=this.currentRoom();
		String nextRoom=room.getNextRoom(direction, doorPosition);
		player.setRoom(nextRoom);
		gui.changeRoom();
	}
	
	/**
	 * Responds to turning based on player's current direction.
	 * Changes players direction and calls GUI to change the user's view.
	 * @param turnMovement name of the turn movement
	 */
	public void turnResponse(String turnMovement) {
		String startDirection=player.getCurrentDirection();
		String endDirection=directions.getTurnEnd(turnMovement, startDirection);
		player.setDirection(endDirection);
		gui.turnResponse();
	}

}
