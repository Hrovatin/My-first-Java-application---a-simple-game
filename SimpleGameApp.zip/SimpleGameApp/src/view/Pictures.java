package view;

import org.apache.commons.collections4.map.MultiKeyMap;
import javafx.scene.image.Image;
import java.net.URL;
import java.util.HashMap;

/**
 * Class (singleton) for storing information about names of picture files
 * (inside images package) used in the game and 
 * passing of Image object to the GUI class. 
 */
public class Pictures {
	
	private static Pictures instance = null; 
	private MultiKeyMap<String,String> roomDirections=new MultiKeyMap<String,String>();
	private HashMap<String,String> items=new HashMap<String,String>();
	
	/**
	 * Singleton constructor.
	 */
	private Pictures() {}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static Pictures getInstance() {
       
		if (instance == null) 
            instance = new Pictures(); 
  
        return instance; 
    } 
	
	/**
	 * Add file name of room's picture in particular direction to the collection.
	 * @param roomName name of the room 
	 * @param direction view direction
	 * @param imageFile file name of the image for the room and direction
	 */
	public void addRoomPicture(String roomName, String direction, String imageFile) {
		roomDirections.put(roomName, direction, imageFile);
	} 
	
	/**
	 * Add file name of items's picture to the collection.
	 * @param itemName name of the item
	 * @param imageFile file name of the image for the item
	 */
	public void addItemPicture(String itemName, String imageFile) {
		items.put(itemName, imageFile);
	}
	
	/**
	 * Returns room view picture based on room and direction.
	 * If created image is empty it replaces it with default image.
	 * @param roomName name of the room
	 * @param direction view direction
	 * @return image object for the room and direction
	 */
	public Image getRoomPicture(String roomName, String direction) {
		String imageFile=roomDirections.get(roomName, direction);
		imageFile=testPath(imageFile,roomName+" "+direction);
		URL imageURL = this.getClass().getResource("/images/"+imageFile);
		imageURL=testImageURL(imageURL,roomName+" "+direction);
		Image image=new Image(imageURL.toString());
		image=testImageNotEmpty(image, roomName+" "+direction);
		return image;
	}
	
	/**
	 * Returns item picture based on item's name.
	 * If created image is empty it replaces it with default image.
	 * @param itemName name of the item
	 * @return image object for the item
	 */
	public Image getItemPicture(String itemName) {
		String imageFile=items.get(itemName); 
		imageFile=testPath(imageFile,itemName);
		URL imageURL = this.getClass().getResource("/images/"+imageFile);
		Image image=new Image(imageURL.toString());
		image=testImageNotEmpty(image, itemName);
		return image;
	}
	
	/**
	 * Checks that imageFile name retrieved from the collection is not an empty
	 * string. If it is empty, it replaces it with the default image file name.
	 * The noted error is printed in the command line.
	 * @param imageFile image file name to be tested
	 * @param imageForWhat description of what the image should represent
	 * @return valid imageFIle, either original or default one
	 */
	private String testPath(String imageFile,String imageForWhat) {
		if (imageFile==null) {
			imageFile="empty.png";
			System.out.println("No image file is associated with "+imageForWhat);
		}
		return imageFile;
	}
	
	/**
	 * Checks that imageFile URL retrieved from the file system is not null. 
	 * If it is null, it replaces it with the URL for default image.
	 * The noted error is printed in the command line.
	 * @param imageURL URL to be tested
	 * @param imageForWhat description of what the image with tested URL should represent
	 * @return valid URL, either original or default one
	 */
	private URL testImageURL(URL imageURL,String imageForWhat) {
		if (imageURL==null) {
			imageURL=this.getClass().getResource("/images/"+"empty.png");
			System.out.println("Image file assoicated with "+imageForWhat+" does not exist.");
		}
		return imageURL;
	}
	
	/**
	 * Checks that created image is not empty. 
	 * If it is empty, it replaces it with the default image.
	 * The noted error is printed in the command line.
	 * @param image image object to be tested
	 * @param imageForWhat description of what the tested image should represent
	 * @return non-empty image, either original or default one
	 */
	private Image testImageNotEmpty(Image image,String imageForWhat) {
		if (image.getPixelReader()==null) {
			image=new Image(this.getClass().getResource("/images/"+"empty.png").toString());
			System.out.println("Image  assoicated with "+imageForWhat+" is empty and was replaced in the GUI.");
		}
		return image;
	}
	
}
