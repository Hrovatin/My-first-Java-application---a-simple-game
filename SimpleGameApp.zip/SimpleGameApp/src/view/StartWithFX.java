package view;

import java.io.IOException;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import controller.Controller;
import creator.*;
import itemStoring.Room;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import objectStorage.ControllerStorage;
import objectStorage.RoomStorage;

// This class is sufficient for execution of simple application with 1 user (currently).
// To use if with multiple users the code for start of object creation, room exit checking and 
// controller classes should be moved in Game (requires multy-threading for multiple views). 
/**
 * The main program for starting JavaFX GUI. 
 * Currently it also starts object creation, performs map topology check and starts the controller.
 * @author B
 * @version
 */
public class StartWithFX extends Application {
	
	private RoomStorage<Room> rooms=RoomStorage.getInstance();

//	The bellow code is based on JavaFX examples with modifications.
	/**
	 * JavaFX start method responsible for creation of new GUI from fxml file, showing the 
	 * GUI and start of object creation class and controller on the same thread as GUI.
	 * It also provides the reference to the JavaFX controller object (controllerFX).
	 * @param stage JavaFX stage
	 */
	public void start(Stage stage) {

//		Start of the GUI; extraction of JavaFX controller.
		try {

			FXMLLoader fxmlLoader = new FXMLLoader();
			String viewerFxml = "/view/guiClick.fxml";
			AnchorPane page = (AnchorPane) fxmlLoader.load(this.getClass().getResource(viewerFxml).openStream());
			ControllerFX guiController = fxmlLoader.getController();
			guiController.primaryStage(stage);
			ObjectCreatorHelper helper = ObjectCreatorHelper.getInstance();
			helper.setGUIController(guiController);
			Scene scene = new Scene(page,670,545);
			scene.getStylesheets().add("/view/styleClick.css");
			stage.setScene(scene);
			stage.setMinHeight(300);
			stage.setMinWidth(540);
			stage.show();
		} catch (IOException ex) {
		   Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
		   System.exit(1);
		}

//		Start of object creation class. 
//		The commented line of code can replace the current creator for the use of non-JSON based object creation.
//	 	Creator creator = SimpleObjectCreator.getInstance();		
		Creator creator = ReaderJSON.getInstance();
		creator.start(); 
		
//		Checks that every room got at least one exit during object creation.
//		If exit was not valid it would not have been added to the room, thus leaving a room with no exits
//		(yet still possibly having entry points thus getting player in state of no escape from the room).
		for (Room room:rooms.getAll()) {
			if (room.hasNoExit()) {
				System.out.println("Programme will terminate as room "+room.getName()+" has no exits.");
				System.exit(0);
			}
		}
		
//		Start of controller(s). Same method (in different class, explained in pdf) 
//		could be used when using this game with multiple users and hence controllers.
     	ControllerStorage<Controller> controllerStorage = ControllerStorage.getInstance();
		HashSet<Controller> controllers = controllerStorage.getAll();
		for (Controller controller : controllers) {
			controller.start();
		}
	}

//	Bellow code is based on Assignment1 PictureViewer.
	/**
	 * Start the JavaFX Application. Called from Game's main.
	 * @param args the command line arguments.
	 */
	 public static void main(String args[]) {
	     launch(args);
	     System.exit(0);
	 }
	 
}
