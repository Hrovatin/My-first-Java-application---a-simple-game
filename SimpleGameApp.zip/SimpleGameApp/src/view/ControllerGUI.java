package view;

import commands.UserPossibleCommands;
import controller.Controller;

/**
 * Minimum common set of commands for any GUI controller.
 * In addition to the public start, changeRoom, turnResponse and itemChange
 * method every GUI should also have private methods enabling the user to exit,
 * turn and pick up/drop down an item. The private methods send the information 
 * about the user's actions to the associated controller.
 */
public interface ControllerGUI {
	
	/**
	 * Connects GUI controller with its non-GUI controller and set of possible commands
	 * for its user.
	 * @param controllerObject Controller class object associated with the GUI controller
	 * @param possibleCommandsObject UserPossibleCommands class object associated with 
	 * 		  the GUI controller
	 */
	public void fieldsView(Controller controllerObject, UserPossibleCommands possibleCommandsObject);
	
	/**
	 * Show the initial view to the user.
	 */
	public void start();
	
	/**
	 * Changes the GUI based on player's movement from one room to another.
	 * This method need is called from the controller.
	 */
	public void changeRoom();
	
	/**
	 * Changes the GUI based on player's turn movement.
	 * This method need is called from the controller.
	 */
	public void turnResponse();
	
	/**
	 * Changes the GUI based on player's act of picking up or putting down an item.
	 * This method need is called from the controller.
	 */
	public void itemChange();
	
}
