package view;

import commands.UserPossibleCommands;
import controller.Controller;
import javafx.geometry.Insets;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import java.util.Set;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;

/**
 * Controller class for JavaFX GUI.
 * Amends user's view according to the current game state, 
 * offers possible commands to the user through the GUI and
 * sends information about user's action to the controller object
 * associated with this user/GUI.
 */
public class ControllerFX implements ControllerGUI{
		
	private Pictures pictureStorage=Pictures.getInstance();
	private Controller controller;
	private UserPossibleCommands possibleCommands;
	private Stage stage;
	
	@FXML
	private HBox turnBar;
	
	@FXML
	private HBox doorBar;
	
	@FXML
	private Label currentRoom;
	
	@FXML
	private VBox itemPanePlayer;
	
	@FXML
	private HBox itemPaneRoom;
	
	@FXML
	private ImageView roomView;
	
	@FXML
	private Pane imagePane;
	
	@FXML
	private AnchorPane main;
	
	@FXML
	private Button helpButton;

	/**
	 * Connect the GUI controller with the non-GUI controller and class for user's possible commands.
	 */
	public void fieldsView(Controller controllerObject, UserPossibleCommands possibleCommandsObject) {
		controller=controllerObject;
		possibleCommands=possibleCommandsObject;
	}
	
	public void primaryStage(Stage stage) {
		this.stage=stage;
	}
	
	/**
	 * Set layout of certain features on GUI*.
	 * Set up the initial view elements (images, buttons).
	 */
//	*I think there may be options to set it in SceneBuilder but non of them worked
//	for me so I decided to encode it here. 
	public void start() {
		
//		Set layout for throughout the game.
//		Minimal stage dimensions are set in start method of the Application. 
		itemPanePlayer.setAlignment(Pos.TOP_CENTER);
		itemPaneRoom.setAlignment(Pos.CENTER);
		roomView.fitWidthProperty().bind(imagePane.widthProperty());
		roomView.fitHeightProperty().bind(imagePane.heightProperty());enableExit();
		
//		Set images and buttons for initial user's view.
		helpButton.setOnAction(e->helpWindow("Left click on item image to pick up or put down an item."
				+ "\nRight click on item or room image to find additional information about the item."));
		currentRoom();
		enableTurn();
		itemViewPlayer();
		itemViewRoom();
		roomView();
	}
	
	/**
	 * Method to be called from Controller when playr's room is changed.
	 * Changes room image and name, room item images, possible items to pick up
	 * and possible exits.
	 */
	public void changeRoom() {
		currentRoom();
		enableExit();
		itemViewRoom();
		roomView();
	}
	
	/**
	 * Method to be called from Controller when playr's direction is changed.
	 * Changes possible turn movements, exits and room image.
	 */
	public void turnResponse() {
		enableTurn();
		enableExit();
		roomView();
	}
	
	/**
	 * Method to be called from Controller when items are picked or dropped.
	 * Changes possible items to pick up and put down and images of room items.
	 */
	public void itemChange() {
		itemViewRoom();
		itemViewPlayer();
	}
	
	/**
	 * Sets name of the current room.
	 */
	private void currentRoom() {
		String name=possibleCommands.currentRoomName();
		currentRoom.setText(name);
	}
	
	/**
	 * Clear the turnBar and add buttons for current possible movements 
	 * (excluding exit movements).
	 * The buttons, when set on action, call Controller's turn response method.
	 */
	private void enableTurn() {
		turnBar.getChildren().clear();
		Set<String>turns=possibleCommands.possibleTurns();
		for (String turn:turns) {
			Button button = addButtonsHBox(turn, turnBar);
			button.setOnAction(e -> controller.turnResponse(turn));
		}
	}
	
	/**
	 * Clear the doorBar and add buttons for currently available exits.
	 * The buttons, when set on action, call Controller's exit response method.
	 */
	private void enableExit() {
		doorBar.getChildren().clear();
		Set<String> exits=possibleCommands.possibleExits();
		if (exits.isEmpty()) {
			Label label=makeLabel("No doors in this direction,\nturn around.");
			label.setPadding(new Insets(0,0,20,0));
			doorBar.getChildren().add(label);
		}
		for (String exit:exits) {
			Button button=addButtonsHBox(exit, doorBar);
			button.setOnAction(e -> controller.goResponse(exit));
		}
	}
	
	/**
	 * Make a new label item with specified text.
	 * @param text to be put on the label
	 * @return label
	 */
	private Label makeLabel(String text) {
		Label label=new Label();
		label.setText(text);
		return label;
	}
	
	/**
	 * Create a button with specified text and add it to the specified HBox.
	 * @param text to be put on the button
	 * @param hboxFxid fx:id of the HBox on which the button should be placed
	 * @return the button object
	 */
	private Button addButtonsHBox(String text, HBox hboxFxid) {
		Button button=new Button();
		button.setText(text);
		hboxFxid.getChildren().add(button);
		return button;
	}
	
	/**
	 * Clears room's item image sloth, creates images of items present in the room and 
	 * adds them to room's item image sloth. 
	 * These item images can be clicked on to pick up the item (left click) or to find 
	 * additional information about the item (right click).
	 * One item with that name is picked up by default.
	 */
	private void itemViewRoom() {
		itemPaneRoom.getChildren().clear();
		Object[] items=possibleCommands.roomItems().toArray();
		for (Object item:items) {
			ImageView imageSloth=makeItemView(item.toString());
			itemPaneRoom.getChildren().add(imageSloth);
			imageSloth.setOnMousePressed(new EventHandler<MouseEvent>() {
				 
	            @Override
	            public void handle(MouseEvent event) {
	                MouseButton mouseButton = event.getButton();
	                if(mouseButton==MouseButton.PRIMARY){
	                	controller.pickUpResponse(item.toString(),1);
	                }	
	                if(mouseButton==MouseButton.SECONDARY){
	                	helpWindow(item.toString());
	                }
	            }
	        });
		}
	}
	
	/**
	 * Clears player's item image sloth, creates images of items possessed by the player 
	 * and adds them to player's item image sloth. 
	 * These item images can be clicked on to put down the item (left click) or to find 
	 * additional information about the item (right click). 
	 * One item with that name is put down by default.
	 */
	private void itemViewPlayer() {
		itemPanePlayer.getChildren().clear();
		Object[] items=possibleCommands.playerItems().toArray();
		for (Object item:items) {
			ImageView imageSloth=makeItemView(item.toString());
			itemPanePlayer.getChildren().add(imageSloth);
			imageSloth.setOnMousePressed(new EventHandler<MouseEvent>() {
				 
	            @Override
	            public void handle(MouseEvent event) {
	                MouseButton mouseButton = event.getButton();
	                if(mouseButton==MouseButton.PRIMARY){
	                	controller.putDownResponse(item.toString(),1);
	                }	
	                if(mouseButton==MouseButton.SECONDARY){
	                	helpWindow(item.toString());
	                }
	            }
	        });
		}
	}
	
	/**
	 * Makes ImageView of the item from the Image from Pictures class.
	 * @param item name of the item
	 * @return ImageView of the item
	 */
	private ImageView makeItemView(String item) {
		Image picture=pictureStorage.getItemPicture(item);
		ImageView imageSloth=new ImageView();
		imageSloth.setImage(picture);
		imageSloth.setFitWidth(64);
		imageSloth.setFitHeight(64);
		return imageSloth;
	}
	

	/**
	 * Sets the image for the current room view based on 
	 * player's current room and direction. 
	 * The room image can be right clicked on to get additional 
	 * information about the room.
	 */
	private void roomView() {
		String room=possibleCommands.currentRoomName();
		String direction=possibleCommands.currentDirection();
		Image picture=pictureStorage.getRoomPicture(room,direction);
		roomView.setImage(picture);	
		roomView.setOnMousePressed(new EventHandler<MouseEvent>() {
			 
            @Override
            public void handle(MouseEvent event) {
                MouseButton mouseButton = event.getButton();
                if(mouseButton==MouseButton.SECONDARY){
                	helpWindow("Room: "+room+"\nDirection: "+direction);
                }
            }
        });
	}
	
	/**
	 * Response to the click of help button.
	 * Opens a new window with the instructions.
	 * Text is wrapped in new line as needed.
	 * Window allows to continue playing even when still displayed.
	 * @param text help message
	 */
	private void helpWindow(String text) {
		final Stage help = new Stage();
	    help.initOwner(stage);
	    VBox helpPane = new VBox();
	    helpPane.setPadding(new Insets(10, 10, 10, 10));
	    Label label=new Label();
	    label.setWrapText(true);
	    label.setText(text);
	    helpPane.getChildren().add(label);
	    Scene helpScene = new Scene(helpPane, 300, 200);
	    help.setScene(helpScene);
	    helpScene.getStylesheets().add("/view/styleClick.css");
	    help.show(); 
	}
}





















































