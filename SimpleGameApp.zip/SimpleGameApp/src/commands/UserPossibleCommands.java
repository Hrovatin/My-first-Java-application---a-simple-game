package commands;

import itemStoring.*;
import objectStorage.RoomStorage;
import java.util.Set;
import org.apache.commons.collections4.bag.HashBag;


/**
 * Supplies methods for determining all current possible actions of the user/player.
 * The actions refer to: position of player, movements, exiting and dealing with items.
 * Has stored the player instance it is dealing with. 
 */
public class UserPossibleCommands {
	
	private Player player;
	private RoomStorage<Room> roomStorage=RoomStorage.getInstance();
	private Directions directions=Directions.getInstance();
	
	/**
	 * Stores the player which commands it navigates.
	 * @param player associated with this object
	 */
	public UserPossibleCommands(Player player) {
		this.player=player;
	}

	/**
	 * Finds current location of the player.
	 * @return room object in which the player is located
	 */
	private Room currentRoom() {
		String roomName=player.getCurrentRoom();
		Room room=roomStorage.get(roomName);
		return room;
	}
	
	/**
	 * Finds current location of the player.
	 * @return name of the room in which the player is located
	 */
	public String currentRoomName() {
		String roomName=player.getCurrentRoom();
		return roomName;
	}
	
	public String currentDirection() {
		String direction=player.getCurrentDirection();
		return direction;
	}
	
	/**
	 * Based on player's direction determines which moves are currently possible.
	 * @return set of possible movements
	 */
	public Set<String> possibleTurns(){
		Set<String> turns=directions.getMovementsFromDirection(player.getCurrentDirection());
		return turns;
	}
	
	/**
	 * Based on players location determines currently available exits.
	 * @return set of available exits
	 */
	public Set<String> possibleExits(){
		Room room=this.currentRoom();
		String direction=player.getCurrentDirection();
		Set<String> exits=room.getExits(direction);
		return exits;
	}
	
	/**
	 * Determines which items the player currently possesses. 
	 * @return bag of item names possessed by the player
	 */
	public HashBag<String> playerItems(){
		HashBag<String> items=player.getItems();
		return items;
	}
	
	/**
	 * Determines which items are in the room where player is located. 
	 * @return bag of item names present in player's current room
	 */
	public HashBag<String>roomItems(){
		Room room=this.currentRoom();
		HashBag<String> items=room.getItems();
		return items;
	}
	
}
