package commands;

import org.apache.commons.collections4.map.MultiKeyMap;
import org.apache.commons.collections4.multimap.HashSetValuedHashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Class (singleton) stores all possible movements and directions.
 * These are the same for all the rooms. However, based on this class another class 
 * could restrict certain options only to specific rooms.
 * It has default movements that can be overwritten. 
 * Processes the outcome of a specific movement (eg. end direction).
 */
public class Directions {
	
	private static Directions instance = null; 
	private MultiKeyMap<String,String> directionMovement=new MultiKeyMap<String,String> ();
	private HashSet<String> allDirections=new HashSet<String>();
	private HashSetValuedHashMap<String,String> startOfMovement=new HashSetValuedHashMap<String,String>();
	
	/**
	 * Singleton constructor
	 */
	private Directions() {

// 		Default movement options.
		addTurnDirection("left", "west","south");
		addTurnDirection("left", "south","east");
		addTurnDirection("left", "east","north");
		addTurnDirection("left", "north","west");
		addTurnDirection("right", "west","north");
		addTurnDirection("right", "north","east");
		addTurnDirection("right", "east","south");
		addTurnDirection("right", "south","west");
	}
	
	/**
	 * Method allowing this class to be singleton, returning the instance of this class.
	 * @return the only instance of this class
	 */
	public static Directions getInstance() {
	       
		if (instance == null) 
            instance = new Directions(); 
  
        return instance; 
    } 
	
	/**
	 * Adds new movement act options.
	 * Stores valid directions and movements.
	 * @param turnMovement name of the movement act
	 * @param startDirection start direction of player before he moves
	 * @param endDirection end direction of player after he moves
	 */
	public void addTurnDirection(String turnMovement, String startDirection, String endDirection) {
		
//		Adds new movement option.
		directionMovement.put(turnMovement,  startDirection, endDirection);
		
//		Adds any new directions and movements to other collections.
		if(!allDirections.contains(startDirection)) {
			allDirections.add(startDirection);
		}
		if(!startOfMovement.get(startDirection).contains(turnMovement)) {
			startOfMovement.put(startDirection,turnMovement);
		}
	}
	
	/**
	 * Processes the player's movement to determine the end player's position.
	 * @param turnMovement name of the movement act
	 * @param startDirection start direction of player before he moves
	 * @return end direction of player after he moves
	 */
	public String getTurnEnd(String turnMovement, String startDirection) {
		return directionMovement.get(turnMovement,  startDirection);
	}
	
	/**
	 * Checks if the specified direction is a valid (stored) direction.
	 * @param direction of interest
	 * @return true if direction is valid, else false
	 */
	public Boolean hasDirection(String direction) {
		return allDirections.contains(direction);
	}

	/**
	 * Returns all valid (stored) directions.
	 * @return all valid directions
	 */
	public HashSet<String> getAllDirections() {
		return allDirections;
	}
	
	/**
	 * Returns all stored movements that start from a specified direction.
	 * @param start start direction of player before he moves
	 * @return set of all possible movements starting in this direction
	 */
//	This is needed to enable turn movements only in valid start directions. 
//	Else end would be empty and no further movements would be possible.
//	For example, if it was enabled to look on the floor it would not make sense to enable 
//	down movement, however down movement should be enabled when looking at walls or ceiling.
	protected Set<String> getMovementsFromDirection(String start) {
		Set<String> movements=startOfMovement.get(start);
		return movements;
	}
	
}
