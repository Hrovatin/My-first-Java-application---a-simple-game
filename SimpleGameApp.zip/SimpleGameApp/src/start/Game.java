package start;

import view.StartWithFX;

//The below code (and comments) are based on Assignment1 MyApplication and JavaFX examples.

/**
 * The main program for launching the Game application.
 *
 * @author  B138636
 * @version 1, 2018-11-22 
 */
public class Game  {

	 /**
     * Start the application
     *
     * @param args the command line arguments. 
     */
    public static void main(String args[]) {
    	StartWithFX.main(args);      
    }
    
}

	

