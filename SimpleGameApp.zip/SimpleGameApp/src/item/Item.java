package item;

/**
 * Wrapper class for items. 
 */
public class Item {
	
	private String name;
	
	/**
	 * Set item's name.
	 * This name will be used in code and will be displayed to the user.
	 * @param name of the item
	 */
	public Item(String name){
		this.name=name;
	}
	
	/**
	 * Get items name.
	 * @return name of the item.
	 */
	public String getName(){
		return name;
	}

}
